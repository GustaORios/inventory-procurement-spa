export default function PurchaseOrdersPage() {
  return (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-2xl font-semibold mb-4 bg-blue-500">Purchase Orders</h1>
    </div>
  );
}
