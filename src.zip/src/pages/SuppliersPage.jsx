export default function SuppliersPage() {
  return (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-2xl font-semibold mb-4">Suppliers</h1>
    </div>
  );
}
